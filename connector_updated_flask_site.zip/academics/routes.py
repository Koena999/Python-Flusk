from flask import Blueprint, render_template

academics_bp = Blueprint("academics", __name__, template_folder="../templates/academics")

@academics_bp.route("/")
def index():
    return render_template("academics/index.html")