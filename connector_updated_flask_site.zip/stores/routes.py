from flask import Blueprint, render_template

stores_bp = Blueprint("stores", __name__, template_folder="../templates/stores")

@stores_bp.route("/")
def index():
    return render_template("stores/index.html")