from flask import Blueprint, render_template

logistics_bp = Blueprint("logistics", __name__, template_folder="../templates/logistics")

@logistics_bp.route("/")
def index():
    return render_template("logistics/index.html")